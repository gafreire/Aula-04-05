
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gabriel Freire
 */
public class ex1_2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner exercicio = new Scanner(System.in);
         
         //1
         int num, num2;
         
         System.out.println("Digite um numero: ");
         num = exercicio.nextInt();
         
         num2 = num % 2;
         
         if (num2 == 0) {
             System.out.println("O numero " +num+ "e par!");            
        }else {
             System.out.println("O numero" +num+ "e impar!");
         }
         
         //2
         int ano;
         
         System.out.println("Digite o ano: ");
         ano = exercicio.nextInt();
         
         if (ano >= 2021){
             System.out.println("O ano e do futuro");
         } else {
             if (ano <= 2019) {
                 System.out.println("O ano e do passado");
             } else {
                 System.out.println("O ano e o atual");
             }
         }
         
         //3
         double n1, n2, media = 10;
         String nome;
         
         System.out.println("Digite seu nome: ");
         nome = exercicio.next();
         
         System.out.println("Digite a primeira nota");
         n1 = exercicio.nextDouble();
         
         System.out.println("Digite a segunda nota");
         n2 = exercicio.nextDouble();
         
         media = (n1 + n2) / 2;
         
         if (media < 4) {
             System.out.println("Nome: " +nome+ " Média:" +media+ " Situação:Reprovado");
         } else {
             if (media >= 4 && media < 6) {
                 System.out.println("Nome: " +nome+ " Média:" +media+ " Situação:Recuperacao");
             } else {
                 System.out.println("Nome: " +nome+ " Média:" +media+ " Situação:Aprovado");
             
         }
         }
         
         
         
    }
    
}
