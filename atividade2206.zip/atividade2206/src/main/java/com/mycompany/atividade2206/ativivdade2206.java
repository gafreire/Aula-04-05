/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.atividade2206;

/**
 *
 * @author Gabriel Freire
 */
public class ativivdade2206 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int vetoor[] = new int[10];
        vetoor[0] = 2;
        vetoor[1] = 4;
        vetoor[2] = 6;
        vetoor[3] = 8;
        vetoor[4] = 10;
        vetoor[5] = 12;
        vetoor[6] = 14;
        vetoor[7] = 16;
        vetoor[8] = 20;
        vetoor[9] = 22;
        
        for (int i = 0; i < vetoor.length; i++) {
            System.out.println("Seu vetor " +i+" = "+ vetoor[i]);
        }
        
        vetoor[4]=87;
             
             System.out.println("-------------------------------------");
             System.out.println("Seu vetor " +4+" = "+ vetoor[4]);
        vetoor[2]=57;
             
             System.out.println("-------------------------------------");
             System.out.println("Seu vetor " +2+" = "+ vetoor[2]);
        
        
        
        
        
        
        
    }
    
}
